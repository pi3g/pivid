#!/bin/bash

vid=$1

#vlc $vid
export DISPLAY=:0
lxterminal -e "omxplayer $vid" && xrefresh
